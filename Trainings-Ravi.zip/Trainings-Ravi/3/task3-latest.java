package com.epam.test;

public class task3{

	public static void main (String args[]){
		
		System.out.println(((int)apple(3,2))); // using cast to convert float to int
		System.out.println(apple(3.5f,2.5f));
	}
	
	public static float apple(float daniel, float Amber){
		return daniel + Amber;
	}
	
	
	
	
}