package com.epam.test;

import java.util.Scanner;

//Task 2 and 3
public class task2{

	public static void main (String args[]){
		//2.1
		/*//using scanner object to take input and pring
		Scanner sc=new Scanner(System.in);
		String ipText=sc.next();		// enter hello
		System.out.println(ipText); // print hello in console
		sc.close();
		*/
		//2.2
		System.out.println(calculator (2,3, "add"));
		System.out.println(calculator (2,3, "subtract"));
		System.out.println(calculator (3,0, "division"));
		System.out.println(calculator (2,3, "multiply"));
		
		
		//3
		//using one method for both int and float variables
		System.out.println(((int)apple(3,2))); // using cast to convert float to int
		System.out.println(apple(3.5f,2.5f));
	}
	
	public static float apple(float daniel, float Amber){
		return daniel + Amber;
	}	
	
	
	public static int calculator (int num1,int num2, String method){
		int res = 0;
		switch (method){
			case "add":
				res= num1+num2;;
				break;
			case "subtract":
				res= num1-num2;
				break;
			case "division":
				try {
					res= num1 / num2;
			    } catch (ArithmeticException e) {
			        System.out.println("Invalid operation: " + e.getMessage());
			    }
				break;
			case "multiply":
				res= num1*num2;
				break;
			case "reminder":
				res= num1%num2;
				
				break;
			case "percentage":
				res= num1*num2/100;
				break;
			default:
				System.out.println("incorrect method is provided");
				break;
		}
		return res;
	}
	
}