package com.epam.test;
//Task 4.2
public class Task4_2{

	public static boolean canBalance(int[] nums) {
	   int leftSum = 0 ;
	    for (int cntr = 0; cntr < nums.length-1; cntr++)
	    {
	        leftSum += nums[cntr];
	        int rightSum = 0 ;
	        for (int innCntr = cntr+1 ; innCntr < nums.length-1 ; innCntr++ ){
	            rightSum += nums[innCntr] ;
	        }
	        if (leftSum == rightSum){
	            return true;
	        }
	    }
	   return false;
	}  
	
	public int countClumps(int[] nums) {
	  boolean same = false;
	  int count = 0;
	  for (int cntr = 0; cntr < nums.length-1; cntr++) {
	    if (nums[cntr] == nums[cntr+1] && !same) {
	    	same = true;
	    	count++;
	    }
	    else if (nums[cntr] != nums[cntr+1]) {
	    	same = false;
	    }
	  }
	  return count;
	}		
	
	public int maxMirror(int[] nums) {
	    int max = 0;
	    for(int start = 0; start < nums.length; start++) {
	        for(int begin = nums.length - 1; begin >= 0; begin--) {
	            int size = 0;
	            int i = start;
	            int j = begin;                   
	            while(i < nums.length && j >= 0 && nums[i] == nums[j]) {
	                size++;
	                i++;
	                j--;
	            }
	                                                                              
	            max = Math.max(max, size);
	        }
	    }
	                                                                                            
	    return max;
	}
	
	public boolean linearIn(int[] outer, int[] inner) {
		  int numFound = 0;
		  if(inner.length == 0) {
		     return true;
		  }
		  int innerCntr = 0;
		  for(int cntr = 0; cntr < outer.length; cntr++) {
		     if(outer[cntr] == inner[innerCntr]) {
		        numFound++;
		        innerCntr++;
		     } else if(outer[cntr] > inner[innerCntr]) {
		        return false;
		     }
		     if(numFound == inner.length)
		        return true;
		  }
		  return false;
		}
	
	public int maxSpan(int[] nums) {
		  int spanCnt = 0;
		  int temp = 0;
		  for (int i = 0; i < nums.length; i++) {
		    for (int j = 0; j < nums.length; j++) {
		      if (nums[i] == nums[j]) {
		        temp = j-i+1;
		        spanCnt = Math.max(temp,spanCnt);
		      }
		    }
		  }
		  return spanCnt;
		}

}




	 
	 
	

